from django.db import models


class fornecedor(models.Model):
    id_fornecedor = models.AutoField(primary_key=True)
    nome_fornecedor = models.CharField(max_length=100)
    CNPJ = models.CharField(max_length=14)
def __str__(self):
    return self.nome_fornecedor