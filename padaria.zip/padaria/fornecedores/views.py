from rest_framework import viewsets
from fornecedores.models import fornecedor
from fornecedores.serializers import fornecedorSerializer


class fornecedorViewSet(viewsets.ModelViewSet):
    queryset = fornecedor.objects.all()
    serializer_class = fornecedorSerializer

