from django.contrib import admin
from fornecedores.models import fornecedor

admin.site.register(fornecedor)