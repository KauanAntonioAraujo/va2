from rest_framework import serializers
from fornecedores.models import fornecedor

class  fornecedorSerializer(serializers.ModelSerializer):
    class Meta:

        model =  fornecedor
        fields = '__all__'