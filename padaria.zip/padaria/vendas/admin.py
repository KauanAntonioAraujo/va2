from django.contrib import admin
from vendas.models import Venda

admin.site.register(Venda)