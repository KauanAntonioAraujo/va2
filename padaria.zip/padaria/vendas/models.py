from django.db import models


class Venda(models.Model):
    id_Venda = models.AutoField(primary_key=True)
    condicao_Pagamento = models.CharField(max_length=100)
    finaciamento = models.CharField(max_length=100)
    status_Aprovacao = models.CharField(max_length=100)
    documentacao_Necessaria = models.CharField(max_length=100)
    nota_fiscal = models.CharField(max_length=100)


def __str__(self):
    return self.nome_Venda